# using python 2.6+
import random
import numpy
import sys
import time

# pris de http://rosettacode.org/wiki/Sorting_algorithms/Insertion_sort#Python
def insertion_sort(l):
    for i in xrange(1, len(l)):
        j = i-1 
        key = l[i]
        while (l[j] > key) and (j >= 0):
           l[j+1] = l[j]
           j -= 1
        l[j+1] = key

# pris de http://rosettacode.org/wiki/Sorting_algorithms/Counting_sort#Python
def countingSort(alist):
    maximum = max(alist)
    minimum = min(alist)
    counting_alist = [0]*(maximum-minimum+1)

    for i in alist:
        counting_alist[i-minimum] += 1

    sorted_alist = []
    for i in range(minimum, maximum+1):        
    	if counting_alist[i-minimum] > 0:
            for j in range(0, counting_alist[i-minimum]):
                sorted_alist.append(i)

    return sorted_alist

# Example call
# a = [4, 65, 2, -31, 0, 99, 83, 782, 1]
# a = quickSortPivotFirst(a)
# pris de http://rosettacode.org/wiki/Sorting_algorithms/Quicksort#Python
def quickSortPivotFirst(arr):
    less = []
    pivotList = []
    more = []
    if len(arr) <= 1:
        return arr
    else:
        pivot = arr[0]
        for i in arr:
            if i < pivot:
                less.append(i)
            elif i > pivot:
                more.append(i)
            else:
                pivotList.append(i)
        less = quickSortPivotFirst(less)
        more = quickSortPivotFirst(more)
        return less + pivotList + more

# inspire de http://rosettacode.org/wiki/Sorting_algorithms/Quicksort#Python
def quickSortPivotRandom(arr):
    less = []
    pivotList = []
    more = []
    if len(arr) <= 1:
        return arr
    else:
    	index = random.randint(0, len(arr) - 1)
        pivot = arr[index]
        for i in arr:
            if i < pivot:
                less.append(i)
            elif i > pivot:
                more.append(i)
            else:
                pivotList.append(i)
        less = quickSortPivotRandom(less)
        more = quickSortPivotRandom(more)
        return less + pivotList + more

# inspire de http://rosettacode.org/wiki/Sorting_algorithms/Quicksort#Python
def quickSortPivotFirstSeuil(arr):
    less = []
    pivotList = []
    more = []
    if len(arr) <= 1:
        return arr
    else:
        pivot = arr[0]
        for i in arr:
            if i < pivot:
                less.append(i)
            elif i > pivot:
                more.append(i)
            else:
                pivotList.append(i)
        seuil = 0 # TODO
        if len(less) >= seuil:
        	less = quickSortPivotFirst(less)
        else:
        	insertion_sort(less)
        if len(more) >= seuil:
        	more = quickSortPivotFirst(more)
        else:
        	insertion_sort(more)
        return less + pivotList + more

# inspire de http://rosettacode.org/wiki/Sorting_algorithms/Quicksort#Python
def quickSortPivotRandomSeuil(arr):
    less = []
    pivotList = []
    more = []
    if len(arr) <= 1:
        return arr
    else:
        index = random.randint(0, len(arr) - 1)
        pivot = arr[index]
        for i in arr:
            if i < pivot:
                less.append(i)
            elif i > pivot:
                more.append(i)
            else:
                pivotList.append(i)
        seuil = 0 # TODO
        if len(less) >= seuil:
        	less = quickSortPivotRandom(less)
        else:
        	insertion_sort(less)
        if len(more) >= seuil:
        	more = quickSortPivotRandom(more)
        else:
        	insertion_sort(more)
        return less + pivotList + more

# sample call: python quicksort.py (numdufichier.txt) (n) (1|2|3|4|5)
# where n is the number of elements in the file you want to sort 
# where 1: countingSort, 2: quickSortPivotFirst, 3: quickSortPivotRandom, 4: quickSortPivotFirstSeuil, %: quickSortPivotRandomSeuil
def main():
	with open(sys.argv[1]) as f:
		arr = []
		n = int(sys.argv[2])
		for line in f:
			arr.append(int(line))
			n -= 1
			if n == 0:
				break
	if sys.argv[3] == "1":
		
		t0 = time.time()
		arr = countingSort(arr)
	elif sys.argv[3] == "2":
		t0 = time.time()
		arr = quickSortPivotFirst(arr)
	elif sys.argv[3] == "3":
		t0 = time.time()
		arr = quickSortPivotRandom(arr)
	elif sys.argv[3] == "4":
		t0 = time.time()
		arr = quickSortPivotFirstSeuil(arr)
	elif sys.argv[3] == "5":
		t0 = time.time()
		arr = quickSortPivotRandomSeuil(arr)
	t1 = time.time()
	total = t1 - t0
	print(total)

if __name__ == "__main__":
	main()
